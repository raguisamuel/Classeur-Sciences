# No special rules needed: saved data uses explicit string keys, not class or enum names.
