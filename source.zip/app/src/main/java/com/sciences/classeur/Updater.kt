package com.sciences.classeur

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Checks GitHub for a newer build and installs it from inside the app. */
object Updater {
    private const val REPO = "raguisamuel/Classeur-Sciences"
    const val APK_URL = "https://github.com/$REPO/releases/latest/download/ClasseurSciences.apk"

    data class Info(val version: Int, val name: String)

    fun currentVersion(context: Context): Long = try {
        context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode
    } catch (_: Exception) {
        Long.MAX_VALUE
    }

    /** Tags look like v1.0.<build number>; the build number is also the app's versionCode. */
    fun fetchLatest(): Info? = try {
        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.inputStream.use { s ->
            val tag = JSONObject(s.bufferedReader().readText()).getString("tag_name")
            tag.substringAfterLast('.').toIntOrNull()?.let { Info(it, tag.removePrefix("v")) }
        }
    } catch (_: Exception) {
        null
    }

    /** Removes APKs left over from earlier updates. */
    fun cleanOldDownloads(context: Context) {
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.listFiles()
            ?.filter { it.name.endsWith(".apk") }
            ?.forEach { it.delete() }
    }

    suspend fun downloadAndInstall(context: Context, onProgress: (Float) -> Unit): Boolean {
        val dm = context.getSystemService(DownloadManager::class.java) ?: return false
        val request = DownloadManager.Request(Uri.parse(APK_URL))
            .setTitle("Classeur Sciences")
            .setDescription("Mise à jour")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "ClasseurSciences-${System.currentTimeMillis()}.apk")
        val id = try {
            dm.enqueue(request)
        } catch (_: Exception) {
            return false
        }
        while (true) {
            delay(400)
            val row = withContext(Dispatchers.IO) {
                dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (!c.moveToFirst()) null
                    else Triple(
                        c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                        c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                        c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                    )
                }
            } ?: return false
            val (status, done, total) = row
            if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val uri = dm.getUriForDownloadedFile(id) ?: return false
                    val install = Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    return try {
                        context.startActivity(install)
                        true
                    } catch (_: Exception) {
                        false
                    }
                }
                DownloadManager.STATUS_FAILED -> return false
            }
        }
    }

    fun openInBrowser(context: Context) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(APK_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

/** Shown once per app start when GitHub has a newer version. */
@Composable
fun UpdateChecker() {
    val ctx = LocalContext.current
    var latest by remember { mutableStateOf<Updater.Info?>(null) }
    var dismissed by rememberSaveable { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val info = withContext(Dispatchers.IO) {
            Updater.cleanOldDownloads(ctx)
            Updater.fetchLatest()
        }
        if (info != null && info.version > Updater.currentVersion(ctx)) latest = info
    }

    val info = latest
    if (info == null || dismissed) return
    val p = progress
    AlertDialog(
        onDismissRequest = { if (progress == null) dismissed = true },
        title = { Text("Nouvelle version disponible") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("La version ${info.name} est prête. Vos leçons, révisions et examens restent enregistrés.")
                if (p != null) {
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                    Text("Téléchargement… ${(p * 100).toInt()} %")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = p == null, onClick = {
                progress = 0f
                scope.launch {
                    val ok = Updater.downloadAndInstall(ctx) { progress = it }
                    if (!ok) {
                        Toast.makeText(ctx, "Téléchargement impossible ici, ouverture du navigateur…", Toast.LENGTH_LONG).show()
                        Updater.openInBrowser(ctx)
                    }
                    progress = null
                    dismissed = true
                }
            }) { Text("Mettre à jour") }
        },
        dismissButton = {
            if (p == null) TextButton(onClick = { dismissed = true }) { Text("Plus tard") }
        },
    )
}
