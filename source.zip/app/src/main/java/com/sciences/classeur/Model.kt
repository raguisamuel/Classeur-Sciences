package com.sciences.classeur

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

const val DEFAULT_CHAPTERS = 5
const val DEFAULT_LESSONS = 2

enum class Kind(
    val key: String,
    val plural: String,
    val addLabel: String,
    val savedLabel: String,
    val emoji: String,
    val color: Color,
) {
    LESSON("lesson", "Leçons", "Ajouter une leçon", "Leçons enregistrées", "📘", Color(0xFF1E6FD9)),
    REVISION("revision", "Révisions", "Ajouter une révision", "Révisions enregistrées", "🔁", Color(0xFF2E9E5B)),
    EXAM("exam", "Examens", "Ajouter un examen", "Examens enregistrés", "📝", Color(0xFFD9652A));

    companion object {
        fun fromKey(k: String) = entries.first { it.key == k }
    }
}

fun yearLabel(y: Int) = "${y}ème année"
fun termLabel(t: Int) = if (t == 1) "1er semestre" else "2ème semestre"
fun lessonsLabel(from: Int, to: Int) = if (from == to) "Leçon $from" else "Leçons $from à $to"
fun countLabel(n: Int) = if (n <= 1) "$n élément" else "$n éléments"

/** A photo or PDF kept by the app in Documents/Classeur Sciences (or, before saving, the picked original). */
data class FileRef(val uri: String, val name: String, val mime: String) {
    val isPdf get() = mime == "application/pdf" || name.endsWith(".pdf", ignoreCase = true)
}

data class Entry(
    val id: String,
    val kind: Kind,
    val year: Int,
    val term: Int,
    val chapter: Int,
    val from: Int,
    val to: Int,
    val files: List<FileRef>,
    val createdAt: Long,
) {
    val label get() = lessonsLabel(from, to)
    val folder get() = folderFor(kind, year, term, chapter, from, to)
}

/** Where the files live on the phone, same tree as in the app. */
fun folderFor(kind: Kind, year: Int, term: Int, chapter: Int, from: Int, to: Int) =
    "${FileAccess.ROOT}/${kind.plural}/${yearLabel(year)}/${termLabel(term)}/Chapitre $chapter/${lessonsLabel(from, to)}"

/** Keeps only the small index (folders + links) in the app's own storage. */
class Store private constructor(context: Context) {
    private val file = File(context.filesDir, "classeur.json")
    private val structFile = File(context.filesDir, "structure.json")
    val entries = mutableStateListOf<Entry>()

    /** Chapters per "year-term" and lessons per "year-term-chapter", shared by Leçons, Révisions and Examens. */
    private val structure = mutableStateMapOf<String, List<Int>>()

    init {
        load()
        loadStructure()
    }

    // ------------------------------------------------ chapters & lessons (folders)

    fun chapters(y: Int, t: Int): List<Int> {
        val base = structure["$y-$t"] ?: (1..DEFAULT_CHAPTERS).toList()
        val used = entries.filter { it.year == y && it.term == t }.map { it.chapter }
        return (base + used).distinct().sorted()
    }

    fun lessons(y: Int, t: Int, c: Int): List<Int> {
        val base = structure["$y-$t-$c"] ?: (1..DEFAULT_LESSONS).toList()
        val used = chapterItems(y, t, c).flatMap { listOf(it.from, it.to) }
        return (base + used).distinct().sorted()
    }

    /** Adds the next folder number (fills a gap first, otherwise last + 1). */
    fun addChapter(y: Int, t: Int): Int {
        val list = chapters(y, t)
        val n = nextNumber(list)
        structure["$y-$t"] = (list + n).sorted()
        persistStructure()
        return n
    }

    fun addLesson(y: Int, t: Int, c: Int): Int {
        val list = lessons(y, t, c)
        val n = nextNumber(list)
        structure["$y-$t-$c"] = (list + n).sorted()
        persistStructure()
        return n
    }

    /** Everything (leçons, révisions, examens) inside a chapter folder. */
    fun chapterItems(y: Int, t: Int, c: Int) = entries.filter { it.year == y && it.term == t && it.chapter == c }

    /** Everything that covers this lesson: the lesson itself and revisions/exams whose range includes it. */
    fun lessonItems(y: Int, t: Int, c: Int, l: Int) = chapterItems(y, t, c).filter { l in it.from..it.to }

    fun deleteChapter(context: Context, y: Int, t: Int, c: Int) {
        chapterItems(y, t, c).map { it.id }.forEach { delete(context, it) }
        structure["$y-$t"] = chapters(y, t) - c
        structure.remove("$y-$t-$c")
        persistStructure()
    }

    fun deleteLesson(context: Context, y: Int, t: Int, c: Int, l: Int) {
        lessonItems(y, t, c, l).map { it.id }.forEach { delete(context, it) }
        structure["$y-$t-$c"] = lessons(y, t, c) - l
        persistStructure()
    }

    private fun nextNumber(list: List<Int>): Int {
        var n = 1
        while (n in list) n++
        return n
    }

    private fun loadStructure() {
        if (!structFile.exists()) return
        runCatching {
            val o = JSONObject(structFile.readText())
            o.keys().forEach { k ->
                val a = o.getJSONArray(k)
                structure[k] = List(a.length()) { a.getInt(it) }
            }
        }
    }

    private fun persistStructure() {
        val o = JSONObject()
        structure.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        structFile.writeText(o.toString())
    }

    fun count(kind: Kind) = entries.count { it.kind == kind }
    fun find(id: String) = entries.firstOrNull { it.id == id }
    fun uses(uri: String) = entries.any { e -> e.files.any { it.uri == uri } }

    /** Saves under year > term > chapter > lessons. Same place again = files are added to it. */
    fun save(kind: Kind, year: Int, term: Int, chapter: Int, from: Int, to: Int, files: List<FileRef>): String {
        val i = entries.indexOfFirst {
            it.kind == kind && it.year == year && it.term == term && it.chapter == chapter && it.from == from && it.to == to
        }
        val id: String
        if (i >= 0) {
            val e = entries[i]
            entries[i] = e.copy(files = merge(e.files, files))
            id = e.id
        } else {
            id = UUID.randomUUID().toString()
            entries.add(Entry(id, kind, year, term, chapter, from, to, files.distinctBy { it.uri }, System.currentTimeMillis()))
        }
        persist()
        return id
    }

    fun addFiles(id: String, files: List<FileRef>) {
        val i = entries.indexOfFirst { it.id == id }
        if (i < 0) return
        entries[i] = entries[i].copy(files = merge(entries[i].files, files))
        persist()
    }

    /** Deletes one file (the app's copy). Returns true if the entry became empty and was deleted. */
    fun removeFile(context: Context, id: String, uri: String): Boolean {
        val i = entries.indexOfFirst { it.id == id }
        if (i < 0) return true
        val left = entries[i].files.filterNot { it.uri == uri }
        val deleted = left.isEmpty()
        if (deleted) entries.removeAt(i) else entries[i] = entries[i].copy(files = left)
        persist()
        if (!uses(uri)) FileAccess.deleteCopy(context, uri)
        return deleted
    }

    fun delete(context: Context, id: String) {
        val e = find(id) ?: return
        entries.remove(e)
        persist()
        e.files.forEach { if (!uses(it.uri)) FileAccess.deleteCopy(context, it.uri) }
    }

    private fun merge(old: List<FileRef>, new: List<FileRef>) = old + new.filter { n -> old.none { it.uri == n.uri } }.distinctBy { it.uri }

    private fun load() {
        if (!file.exists()) return
        runCatching {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) entries.add(fromJson(arr.getJSONObject(i)))
        }
    }

    private fun persist() {
        val arr = JSONArray()
        entries.forEach { arr.put(toJson(it)) }
        val tmp = File(file.path + ".tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(arr.toString())
            tmp.delete()
        }
    }

    private fun toJson(e: Entry) = JSONObject().apply {
        put("id", e.id)
        put("kind", e.kind.key)
        put("year", e.year)
        put("term", e.term)
        put("chapter", e.chapter)
        put("from", e.from)
        put("to", e.to)
        put("createdAt", e.createdAt)
        put("files", JSONArray().apply {
            e.files.forEach { f ->
                put(JSONObject().apply {
                    put("uri", f.uri)
                    put("name", f.name)
                    put("mime", f.mime)
                })
            }
        })
    }

    private fun fromJson(o: JSONObject): Entry {
        val fa = o.getJSONArray("files")
        val files = List(fa.length()) { i ->
            val f = fa.getJSONObject(i)
            FileRef(f.getString("uri"), f.optString("name", "fichier"), f.optString("mime", "image/*"))
        }
        return Entry(
            id = o.getString("id"),
            kind = Kind.fromKey(o.getString("kind")),
            year = o.getInt("year"),
            term = o.getInt("term"),
            chapter = o.getInt("chapter"),
            from = o.getInt("from"),
            to = o.getInt("to"),
            files = files,
            createdAt = o.optLong("createdAt"),
        )
    }

    companion object {
        @Volatile
        private var instance: Store? = null
        fun get(context: Context): Store =
            instance ?: synchronized(this) { instance ?: Store(context.applicationContext).also { instance = it } }
    }
}
