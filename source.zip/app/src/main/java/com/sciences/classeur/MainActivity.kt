package com.sciences.classeur

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store.get(applicationContext)
        setContent { ClasseurTheme { App(store) } }
    }
}

sealed interface Screen {
    data object Home : Screen
    data class Section(val kind: Kind) : Screen
    data class Add(val kind: Kind) : Screen
    data class Browse(val kind: Kind, val year: Int? = null, val term: Int? = null, val chapter: Int? = null) : Screen
    data class Detail(val entryId: String) : Screen
    data class Viewer(val entryId: String, val index: Int) : Screen
}

class Nav(private val stack: SnapshotStateList<Screen>) {
    fun go(s: Screen) {
        stack.add(s)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun replace(s: Screen) {
        stack[stack.lastIndex] = s
    }
}

@Composable
fun App(store: Store) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val nav = remember { Nav(stack) }
    BackHandler(enabled = stack.size > 1) { nav.back() }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        val screen = stack.last()
        key(stack.size, screen) {
            when (screen) {
                Screen.Home -> HomeScreen(store, nav)
                is Screen.Section -> SectionScreen(screen.kind, store, nav)
                is Screen.Add -> AddScreen(screen.kind, store, nav)
                is Screen.Browse -> BrowseScreen(screen, store, nav)
                is Screen.Detail -> DetailScreen(screen.entryId, store, nav)
                is Screen.Viewer -> ViewerScreen(screen.entryId, screen.index, store, nav)
            }
        }
    }
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(store: Store, nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        Header("Sciences", "Mon classeur de cours · 4ème, 5ème, 6ème", Teal, null)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Kind.entries.forEach { k ->
                BigButton(k.plural, countLabel(store.count(k)), k.emoji, k.color) { nav.go(Screen.Section(k)) }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Vos fichiers sont rangés dans le téléphone : Documents › Classeur Sciences, avec les mêmes dossiers.",
                fontSize = 13.sp,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun SectionScreen(kind: Kind, store: Store, nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        Header(kind.plural, null, kind.color, { nav.back() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            BigButton(kind.addLabel, null, "➕", kind.color) { nav.go(Screen.Add(kind)) }
            BigButton(kind.savedLabel, countLabel(store.count(kind)), "📂", kind.color.copy(alpha = 0.85f)) {
                nav.go(Screen.Browse(kind))
            }
        }
    }
}

// ---------------------------------------------------------------- Add (wizard)

@Composable
fun AddScreen(kind: Kind, store: Store, nav: Nav) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    var year by rememberSaveable { mutableIntStateOf(0) }
    var term by rememberSaveable { mutableIntStateOf(0) }
    var chapter by rememberSaveable { mutableIntStateOf(0) }
    var from by rememberSaveable { mutableIntStateOf(0) }
    var to by rememberSaveable { mutableIntStateOf(0) }
    var single by rememberSaveable { mutableStateOf(kind == Kind.LESSON) }
    var modeChosen by rememberSaveable { mutableStateOf(kind != Kind.EXAM) }
    val picked = remember { mutableStateListOf<FileRef>() }
    var deleteOriginals by remember { mutableStateOf(FileAccess.deleteOriginals(ctx)) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            val ref = FileAccess.describe(ctx, uri)
            if (picked.none { it.uri == ref.uri }) picked.add(ref)
        }
    }

    fun goBack() {
        if (saving) return
        when (step) {
            0 -> nav.back()
            1, 2 -> step -= 1
            3 -> when {
                !single && from != 0 -> from = 0
                kind == Kind.EXAM && modeChosen -> {
                    modeChosen = false
                    from = 0
                }
                else -> step = 2
            }
            else -> {
                step = 3
                from = 0
                to = 0
            }
        }
    }
    BackHandler { goBack() }

    val crumbs = buildList {
        if (year > 0) add(yearLabel(year))
        if (term > 0) add(termLabel(term))
        if (chapter > 0) add("Chapitre $chapter")
        if (step == 4) add(lessonsLabel(from, to))
    }.joinToString(" › ")

    Column(Modifier.fillMaxSize()) {
        Header(kind.addLabel, crumbs, kind.color, { goBack() })
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            when (step) {
                0 -> ChoiceList("Quelle année ?", listOf(4, 5, 6).map { yearLabel(it) }, kind.color) {
                    year = 4 + it
                    step = 1
                }
                1 -> ChoiceList("Quel semestre ?", listOf(termLabel(1), termLabel(2)), kind.color) {
                    term = it + 1
                    step = 2
                }
                2 -> NumberGrid("Quel chapitre ?", 1..MAX_CHAPTERS, "Chapitre", kind.color) {
                    chapter = it
                    step = 3
                }
                3 -> when {
                    !modeChosen -> ChoiceList(
                        "L'examen porte sur :",
                        listOf("Une seule leçon", "Plusieurs leçons (de… à…)"),
                        kind.color,
                    ) {
                        single = it == 0
                        modeChosen = true
                    }
                    single -> NumberGrid(
                        if (kind == Kind.LESSON) "Quelle leçon ?" else "Sur quelle leçon ?",
                        1..MAX_LESSONS, "Leçon", kind.color,
                    ) {
                        from = it
                        to = it
                        step = 4
                    }
                    from == 0 -> NumberGrid("De la leçon…", 1..MAX_LESSONS, "Leçon", kind.color) { from = it }
                    else -> NumberGrid("De la leçon $from à la leçon…", from..MAX_LESSONS, "Leçon", kind.color) {
                        to = it
                        step = 4
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Question("Les fichiers")
                    Text(
                        "Choisissez les photos ou les PDF. L'application les range dans son dossier : " +
                            "Documents › Classeur Sciences › ${kind.plural} › … (visible aussi dans le gestionnaire de fichiers).",
                        fontSize = 14.sp,
                        color = Muted,
                    )
                    Button(
                        onClick = { launcher.launch(arrayOf("image/*", "application/pdf")) },
                        colors = ButtonDefaults.buttonColors(containerColor = kind.color),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Choisir des photos / PDF", fontSize = 16.sp)
                    }
                    LazyColumn(
                        Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(picked, key = { _, f -> f.uri }) { _, f ->
                            FileRow(f, onClick = null, onRemove = if (saving) null else ({ picked.remove(f); Unit }))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = deleteOriginals,
                            onCheckedChange = {
                                deleteOriginals = it
                                FileAccess.setDeleteOriginals(ctx, it)
                            },
                            enabled = !saving,
                        )
                        Text(
                            "Supprimer l'original du téléphone après l'enregistrement (pour ne pas garder 2 copies)",
                            fontSize = 13.sp,
                        )
                    }
                    Button(
                        enabled = picked.isNotEmpty() && !saving,
                        onClick = {
                            saving = true
                            val folder = folderFor(kind, year, term, chapter, from, to)
                            val sources = picked.toList()
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { FileAccess.importAll(ctx, sources, folder, deleteOriginals) }
                                if (r.copied.isEmpty()) {
                                    saving = false
                                    Toast.makeText(ctx, "Échec de l'enregistrement des fichiers.", Toast.LENGTH_LONG).show()
                                } else {
                                    val id = store.save(kind, year, term, chapter, from, to, r.copied)
                                    Toast.makeText(ctx, importMessage(r), Toast.LENGTH_LONG).show()
                                    nav.replace(Screen.Detail(id))
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Teal),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (saving) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("Enregistrement…", fontSize = 17.sp, modifier = Modifier.padding(vertical = 6.dp))
                        } else {
                            Text("Enregistrer (${picked.size})", fontSize = 17.sp, modifier = Modifier.padding(vertical = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Saved folders

@Composable
fun BrowseScreen(s: Screen.Browse, store: Store, nav: Nav) {
    val kind = s.kind
    val all = store.entries.filter { it.kind == kind }
    val crumbs = listOfNotNull(
        s.year?.let { yearLabel(it) },
        s.term?.let { termLabel(it) },
        s.chapter?.let { "Chapitre $it" },
    ).joinToString(" › ")

    Column(Modifier.fillMaxSize()) {
        Header(kind.savedLabel, crumbs, kind.color, { nav.back() })
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when {
                s.year == null -> {
                    val years = listOf(4, 5, 6)
                    items(years.size) { i ->
                        val y = years[i]
                        FolderRow("📁", yearLabel(y), countLabel(all.count { it.year == y })) {
                            nav.go(s.copy(year = y))
                        }
                    }
                }
                s.term == null -> {
                    items(2) { i ->
                        val t = i + 1
                        FolderRow("📁", termLabel(t), countLabel(all.count { it.year == s.year && it.term == t })) {
                            nav.go(s.copy(term = t))
                        }
                    }
                }
                s.chapter == null -> {
                    val inTerm = all.filter { it.year == s.year && it.term == s.term }
                    val chapters = inTerm.map { it.chapter }.distinct().sorted()
                    if (chapters.isEmpty()) item { Empty(kind, nav) }
                    items(chapters.size) { i ->
                        val c = chapters[i]
                        FolderRow("📁", "Chapitre $c", countLabel(inTerm.count { it.chapter == c })) {
                            nav.go(s.copy(chapter = c))
                        }
                    }
                }
                else -> {
                    val list = all
                        .filter { it.year == s.year && it.term == s.term && it.chapter == s.chapter }
                        .sortedWith(compareBy({ it.from }, { it.to }))
                    if (list.isEmpty()) item { Empty(kind, nav) }
                    items(list.size) { i ->
                        val e = list[i]
                        val n = e.files.size
                        FolderRow(kind.emoji, e.label, if (n == 1) "1 fichier" else "$n fichiers") {
                            nav.go(Screen.Detail(e.id))
                        }
                    }
                }
            }
        }
    }
}

fun importMessage(r: FileAccess.ImportResult): String = buildString {
    append("Enregistré ✔ (${r.copied.size} fichier(s))")
    if (r.failed > 0) append(" · ${r.failed} n'ont pas pu être copiés")
    if (r.originalsKept > 0) append(" · ${r.originalsKept} original(aux) non supprimé(s), à effacer à la main")
}

@Composable
private fun Empty(kind: Kind, nav: Nav) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Rien ici pour le moment.", color = Muted, fontSize = 16.sp)
        OutlinedButton(onClick = { nav.go(Screen.Add(kind)) }) { Text(kind.addLabel) }
    }
}

// ---------------------------------------------------------------- One saved item

@Composable
fun DetailScreen(entryId: String, store: Store, nav: Nav) {
    val ctx = LocalContext.current
    val entry = store.find(entryId)
    if (entry == null) {
        LaunchedEffect(Unit) { nav.back() }
        return
    }
    val kind = entry.kind
    var toRemove by remember { mutableStateOf<FileRef?>(null) }
    var askDelete by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            adding = true
            val sources = uris.map { FileAccess.describe(ctx, it) }
            val folder = entry.folder
            val del = FileAccess.deleteOriginals(ctx)
            scope.launch {
                val r = withContext(Dispatchers.IO) { FileAccess.importAll(ctx, sources, folder, del) }
                store.addFiles(entryId, r.copied)
                adding = false
                Toast.makeText(ctx, importMessage(r), Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header(
            title = entry.label,
            subtitle = "${yearLabel(entry.year)} › ${termLabel(entry.term)} › Chapitre ${entry.chapter}",
            color = kind.color,
            onBack = { nav.back() },
            actions = {
                IconButton(onClick = { FileAccess.share(ctx, entry.files) }) {
                    Icon(Icons.Filled.Share, contentDescription = "Tout partager", tint = Color.White)
                }
            },
        )
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(entry.files, key = { _, f -> f.uri }) { i, f ->
                FileRow(f, onClick = { nav.go(Screen.Viewer(entryId, i)) }, onRemove = { toRemove = f })
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(
                onClick = { launcher.launch(arrayOf("image/*", "application/pdf")) },
                enabled = !adding,
                colors = ButtonDefaults.buttonColors(containerColor = kind.color),
                modifier = Modifier.weight(1f),
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (adding) "Ajout…" else "Ajouter des fichiers")
            }
            OutlinedButton(onClick = { askDelete = true }) { Text("Supprimer", color = Danger) }
        }
    }

    toRemove?.let { f ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            title = { Text("Retirer ce fichier ?") },
            text = { Text("« ${f.name} » sera supprimé définitivement (c'est la seule copie).") },
            confirmButton = {
                TextButton(onClick = {
                    toRemove = null
                    if (store.removeFile(ctx, entryId, f.uri)) nav.back()
                }) { Text("Retirer", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { toRemove = null }) { Text("Annuler") } },
        )
    }
    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("Supprimer « ${entry.label} » ?") },
            text = { Text("Ses ${entry.files.size} fichier(s) seront supprimés définitivement du téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    askDelete = false
                    store.delete(ctx, entryId)
                    nav.back()
                }) { Text("Supprimer", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Annuler") } },
        )
    }
}
