package com.sciences.classeur

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable

/** Full-screen viewer for the files of one saved item, with Share at the top. */
@Composable
fun ViewerScreen(entryId: String, startIndex: Int, store: Store, nav: Nav) {
    val entry = store.find(entryId)
    if (entry == null || entry.files.isEmpty()) {
        LaunchedEffect(Unit) { nav.back() }
        return
    }
    val ctx = LocalContext.current
    var index by rememberSaveable { mutableIntStateOf(startIndex) }
    val i = index.coerceIn(0, entry.files.lastIndex)
    val ref = entry.files[i]
    BackHandler { nav.back() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF111416))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E2428))
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { nav.back() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(ref.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp)
                Text(
                    "${i + 1} / ${entry.files.size} · ${entry.label}",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                )
            }
            IconButton(onClick = { FileAccess.share(ctx, listOf(ref)) }) {
                Icon(Icons.Filled.Share, contentDescription = "Partager", tint = Color.White)
            }
            TextButton(onClick = { FileAccess.openExternally(ctx, ref) }) {
                Text("Ouvrir avec", color = Color.White, fontSize = 13.sp)
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clipToBounds()
        ) {
            key(ref.uri) {
                if (ref.isPdf) PdfView(ref) else ImageView(ref)
            }
        }

        if (entry.files.size > 1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E2428))
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = { index = i - 1 }, enabled = i > 0) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null, tint = Color.White)
                    Text("Précédent", color = Color.White)
                }
                TextButton(onClick = { index = i + 1 }, enabled = i < entry.files.lastIndex) {
                    Text("Suivant", color = Color.White)
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Color.White)
                }
            }
        }
    }
}

class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(IntSize.Zero)

    fun apply(zoom: Float, pan: Offset) {
        scale = (scale * zoom).coerceIn(1f, 5f)
        val maxX = (scale - 1f) * size.width / 2f
        val maxY = (scale - 1f) * size.height / 2f
        offset = if (scale == 1f) Offset.Zero else Offset(
            (offset.x + pan.x).coerceIn(-maxX, maxX),
            (offset.y + pan.y).coerceIn(-maxY, maxY),
        )
    }

    fun reset() {
        scale = 1f
        offset = Offset.Zero
    }
}

/**
 * Pinch to zoom. Two fingers always zoom/move; one finger moves only when
 * [singleFingerPan] is on and the content is zoomed (so PDF pages still scroll normally).
 */
fun Modifier.zoomable(state: ZoomState, singleFingerPan: Boolean): Modifier =
    this
        .onSizeChanged { state.size = it }
        .pointerInput(state) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val fingers = event.changes.count { it.pressed }
                    if (fingers >= 2 || (singleFingerPan && state.scale > 1f)) {
                        state.apply(event.calculateZoom(), event.calculatePan())
                        event.changes.forEach { it.consume() }
                    }
                } while (event.changes.any { it.pressed })
            }
        }

private data class Loaded(val done: Boolean, val bitmap: ImageBitmap?)

@Composable
private fun ImageView(ref: FileRef) {
    val ctx = LocalContext.current.applicationContext
    val zoom = remember { ZoomState() }
    val loaded by produceState(Loaded(false, null), ref.uri) {
        value = Loaded(true, withContext(Dispatchers.IO) { FileAccess.loadImage(ctx, ref, 2560)?.asImageBitmap() })
    }
    Box(
        Modifier
            .fillMaxSize()
            .zoomable(zoom, singleFingerPan = true)
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { if (zoom.scale > 1f) zoom.reset() else zoom.apply(2.5f, Offset.Zero) })
            },
        contentAlignment = Alignment.Center,
    ) {
        val bmp = loaded.bitmap
        when {
            !loaded.done -> CircularProgressIndicator(color = Color.White)
            bmp == null -> Missing()
            else -> Image(
                bmp,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoom.scale
                        scaleY = zoom.scale
                        translationX = zoom.offset.x
                        translationY = zoom.offset.y
                    },
            )
        }
    }
}

@Composable
private fun Missing() {
    Text(
        "⚠️ Fichier introuvable sur le téléphone.\nIl a peut-être été supprimé ou déplacé.",
        color = Color.White,
        modifier = Modifier.padding(24.dp),
    )
}

/** Renders PDF pages one by one with Android's built-in PdfRenderer (no copy of the file). */
class PdfDoc private constructor(private val pfd: ParcelFileDescriptor) : Closeable {
    private val renderer = PdfRenderer(pfd)
    private var closed = false
    val ratios: List<Float> = List(renderer.pageCount) { i ->
        renderer.openPage(i).use { it.height / it.width.toFloat() }
    }

    @Synchronized
    fun render(index: Int, width: Int): Bitmap? {
        if (closed) return null
        return try {
            renderer.openPage(index).use { page ->
                val h = (width * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }

    companion object {
        fun open(context: Context, ref: FileRef): PdfDoc? = try {
            context.contentResolver.openFileDescriptor(Uri.parse(ref.uri), "r")?.let { PdfDoc(it) }
        } catch (_: Throwable) {
            null
        }
    }
}

@Composable
private fun PdfView(ref: FileRef) {
    val ctx = LocalContext.current.applicationContext
    var doc by remember { mutableStateOf<PdfDoc?>(null) }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(ref.uri) {
        doc = withContext(Dispatchers.IO) { PdfDoc.open(ctx, ref) }
        done = true
    }
    DisposableEffect(ref.uri) { onDispose { doc?.close() } }

    val d = doc
    when {
        !done -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
        d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Missing() }
        else -> {
            val zoom = remember { ZoomState() }
            BoxWithConstraints(
                Modifier
                    .fillMaxSize()
                    .zoomable(zoom, singleFingerPan = false)
            ) {
                val renderWidth = (constraints.maxWidth * 1.5f).toInt().coerceIn(600, 2200)
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = zoom.scale
                            scaleY = zoom.scale
                            translationX = zoom.offset.x
                            translationY = zoom.offset.y
                        },
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(d.ratios.size) { p -> PdfPage(d, p, renderWidth) }
                }
            }
        }
    }
}

@Composable
private fun PdfPage(doc: PdfDoc, index: Int, width: Int) {
    val bmp by produceState<ImageBitmap?>(null, doc, index) {
        value = withContext(Dispatchers.IO) { doc.render(index, width)?.asImageBitmap() }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f / doc.ratios[index].coerceAtLeast(0.05f))
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(b, contentDescription = "Page ${index + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        } else {
            Text("Page ${index + 1}", color = Muted)
        }
    }
}
