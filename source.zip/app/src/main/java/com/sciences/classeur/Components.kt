package com.sciences.classeur

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Teal = Color(0xFF14524F)
val Bg = Color(0xFFF2F7F6)
val Line = Color(0xFFDCE5E3)
val Muted = Color(0xFF5F6F72)
val Danger = Color(0xFFC62828)

fun Color.darker(f: Float = 0.28f) = lerp(this, Color.Black, f)

@Composable
fun ClasseurTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Teal, background = Bg, surface = Color.White),
        content = content,
    )
}

// ---------------------------------------------------------------- background

/** Faint science doodles (atoms, molecules, DNA, flasks, leaves, magnifiers) behind every screen. */
@Composable
fun ScienceBackground(modifier: Modifier = Modifier, tint: Color = Teal) {
    Canvas(modifier) {
        val step = 140.dp.toPx()
        val r = 22.dp.toPx()
        val color = tint.copy(alpha = 0.075f)
        val stroke = Stroke(width = 1.7.dp.toPx(), cap = StrokeCap.Round)
        var row = 0
        var y = step * 0.35f
        while (y < size.height + r) {
            var x = if (row % 2 == 0) step * 0.3f else step * 0.8f
            var col = 0
            while (x < size.width + r) {
                val c = Offset(x, y)
                val angle = (((row * 7 + col * 13) % 5) - 2) * 14f
                rotate(angle, c) {
                    when ((row * 4 + col) % 6) {
                        0 -> atom(c, r, color, stroke)
                        1 -> molecule(c, r, color, stroke)
                        2 -> dna(c, r, color, stroke)
                        3 -> flask(c, r, color, stroke)
                        4 -> leaf(c, r, color, stroke)
                        else -> magnifier(c, r, color, stroke)
                    }
                }
                x += step
                col++
            }
            y += step * 0.82f
            row++
        }
    }
}

private fun DrawScope.atom(c: Offset, r: Float, color: Color, s: Stroke) {
    drawCircle(color, r * 0.16f, c)
    for (a in listOf(0f, 60f, 120f)) {
        rotate(a, c) { drawOval(color, Offset(c.x - r, c.y - r * 0.36f), Size(2 * r, 0.72f * r), style = s) }
    }
}

private fun DrawScope.molecule(c: Offset, r: Float, color: Color, s: Stroke) {
    val p = Path()
    val pts = (0 until 6).map { i ->
        val a = PI / 3 * i + PI / 6
        Offset(c.x + (r * 0.6f * cos(a)).toFloat(), c.y + (r * 0.6f * sin(a)).toFloat())
    }
    p.moveTo(pts[0].x, pts[0].y)
    pts.drop(1).forEach { p.lineTo(it.x, it.y) }
    p.close()
    drawPath(p, color, style = s)
    drawLine(color, pts[0], Offset(pts[0].x + r * 0.45f, pts[0].y + r * 0.25f), s.width, StrokeCap.Round)
    drawCircle(color, r * 0.13f, Offset(pts[0].x + r * 0.5f, pts[0].y + r * 0.28f))
    drawLine(color, pts[3], Offset(pts[3].x - r * 0.45f, pts[3].y - r * 0.25f), s.width, StrokeCap.Round)
    drawCircle(color, r * 0.13f, Offset(pts[3].x - r * 0.5f, pts[3].y - r * 0.28f))
}

private fun DrawScope.dna(c: Offset, r: Float, color: Color, s: Stroke) {
    val a = Path()
    val b = Path()
    val n = 24
    for (i in 0..n) {
        val t = i / n.toFloat()
        val x = c.x - r + 2 * r * t
        val dy = (sin(t * 2 * PI) * r * 0.42f).toFloat()
        if (i == 0) {
            a.moveTo(x, c.y + dy); b.moveTo(x, c.y - dy)
        } else {
            a.lineTo(x, c.y + dy); b.lineTo(x, c.y - dy)
        }
        if (i % 4 == 2) drawLine(color, Offset(x, c.y + dy), Offset(x, c.y - dy), s.width * 0.7f)
    }
    drawPath(a, color, style = s)
    drawPath(b, color, style = s)
}

private fun DrawScope.flask(c: Offset, r: Float, color: Color, s: Stroke) {
    val p = Path().apply {
        moveTo(c.x - r * 0.2f, c.y - r)
        lineTo(c.x - r * 0.2f, c.y - r * 0.3f)
        lineTo(c.x - r * 0.75f, c.y + r * 0.85f)
        lineTo(c.x + r * 0.75f, c.y + r * 0.85f)
        lineTo(c.x + r * 0.2f, c.y - r * 0.3f)
        lineTo(c.x + r * 0.2f, c.y - r)
    }
    drawPath(p, color, style = s)
    drawLine(color, Offset(c.x - r * 0.32f, c.y - r), Offset(c.x + r * 0.32f, c.y - r), s.width, StrokeCap.Round)
    drawLine(color, Offset(c.x - r * 0.5f, c.y + r * 0.35f), Offset(c.x + r * 0.5f, c.y + r * 0.35f), s.width, StrokeCap.Round)
    drawCircle(color, r * 0.07f, Offset(c.x - r * 0.1f, c.y + r * 0.6f))
    drawCircle(color, r * 0.05f, Offset(c.x + r * 0.2f, c.y + r * 0.5f))
}

private fun DrawScope.leaf(c: Offset, r: Float, color: Color, s: Stroke) {
    val p = Path().apply {
        moveTo(c.x, c.y + r)
        quadraticBezierTo(c.x + r * 1.1f, c.y, c.x, c.y - r)
        quadraticBezierTo(c.x - r * 1.1f, c.y, c.x, c.y + r)
    }
    drawPath(p, color, style = s)
    drawLine(color, Offset(c.x, c.y + r * 1.25f), Offset(c.x, c.y - r * 0.7f), s.width, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y), Offset(c.x + r * 0.35f, c.y - r * 0.35f), s.width * 0.8f, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y + r * 0.4f), Offset(c.x - r * 0.35f, c.y + r * 0.05f), s.width * 0.8f, StrokeCap.Round)
}

private fun DrawScope.magnifier(c: Offset, r: Float, color: Color, s: Stroke) {
    val lens = Offset(c.x - r * 0.2f, c.y - r * 0.2f)
    drawCircle(color, r * 0.55f, lens, style = s)
    drawLine(color, Offset(c.x + r * 0.2f, c.y + r * 0.2f), Offset(c.x + r * 0.85f, c.y + r * 0.85f), s.width * 1.8f, StrokeCap.Round)
}

// ---------------------------------------------------------------- headers & buttons

@Composable
fun Header(
    title: String,
    subtitle: String?,
    color: Color,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val shape = RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(6.dp, shape)
            .clip(shape)
            .background(Brush.linearGradient(listOf(color, color.darker())))
            .padding(horizontal = 6.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour", tint = Color.White)
            }
        } else {
            Spacer(Modifier.width(14.dp))
        }
        Column(
            Modifier
                .weight(1f)
                .padding(vertical = 4.dp)
        ) {
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (!subtitle.isNullOrEmpty()) {
                Text(subtitle, color = Color.White.copy(alpha = 0.88f), fontSize = 13.sp)
            }
        }
        actions()
    }
}

/** Big coloured tile used on the home and section screens. */
@Composable
fun BigButton(title: String, subtitle: String?, emoji: String, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, shape, ambientColor = color, spotColor = color)
            .clip(shape)
            .background(Brush.linearGradient(listOf(color, color.darker(0.22f))))
            .clickable(onClick = onClick)
    ) {
        // big faded emoji in the corner, like a sticker
        Text(
            emoji,
            fontSize = 74.sp,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp)
                .graphicsLayer { alpha = 0.18f; rotationZ = -12f },
        )
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 22.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) { Text(emoji, fontSize = 26.sp) }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Color.White)
        }
    }
}

/** White list row: years, terms and saved revisions/exams. Long press = delete (when allowed). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderRow(emoji: String, title: String, subtitle: String?, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(2.dp, shape)
            .clip(shape)
            .background(Color.White)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 26.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = Muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Muted)
    }
}

@Composable
fun Question(text: String) {
    Text(text, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A2626), modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
fun ChoiceList(question: String, options: List<String>, color: Color, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Question(question)
        options.forEachIndexed { i, option ->
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .shadow(2.dp, shape)
                    .clip(shape)
                    .background(Color.White)
                    .border(2.dp, color.copy(alpha = 0.3f), shape)
                    .clickable { onPick(i) }
                    .padding(horizontal = 18.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(option, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = color, modifier = Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = color)
            }
        }
    }
}

// ---------------------------------------------------------------- editable folders

/**
 * Grid of numbered folders (chapters or lessons).
 * Tap = open. "+" tile = add the next one. Long press = edit mode: tiles wiggle and show a red "−".
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderGrid(
    question: String?,
    items: List<Int>,
    caption: String,
    color: Color,
    subtitle: (Int) -> String? = { null },
    onPick: (Int) -> Unit,
    onAdd: (() -> Unit)?,
    onDelete: ((Int) -> Unit)?,
) {
    var editing by remember { mutableStateOf(false) }
    // The wiggle only runs while editing, so it costs nothing the rest of the time.
    val wiggle = if (editing) {
        rememberInfiniteTransition(label = "wiggle").animateFloat(
            initialValue = -2.2f,
            targetValue = 2.2f,
            animationSpec = infiniteRepeatable(tween(120, easing = LinearEasing), RepeatMode.Reverse),
            label = "angle",
        ).value
    } else 0f

    Column {
        if (question != null) Question(question)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (editing) "Touchez − pour supprimer un dossier"
                else if (onDelete != null) "Appui long sur un dossier pour le supprimer" else "",
                fontSize = 12.sp,
                color = Muted,
                modifier = Modifier.weight(1f),
            )
            if (editing) TextButton(onClick = { editing = false }) { Text("Terminé", color = color, fontWeight = FontWeight.Bold) }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
        ) {
            items(items, key = { it }) { n ->
                val tileShape = RoundedCornerShape(20.dp)
                Box(Modifier.padding(6.dp)) {
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .graphicsLayer { rotationZ = if (editing) (if (n % 2 == 0) wiggle else -wiggle) else 0f }
                            .shadow(4.dp, tileShape, ambientColor = color, spotColor = color)
                            .clip(tileShape)
                            .background(Brush.verticalGradient(listOf(Color.White, color.copy(alpha = 0.10f))))
                            .border(1.5.dp, color.copy(alpha = 0.35f), tileShape)
                            .combinedClickable(
                                onClick = { if (editing) editing = false else onPick(n) },
                                onLongClick = if (onDelete != null) ({ editing = true }) else null,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(caption, fontSize = 11.sp, color = color, fontWeight = FontWeight.Medium)
                            Text("$n", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = color)
                            subtitle(n)?.let { Text(it, fontSize = 10.sp, color = Muted, maxLines = 1) }
                        }
                    }
                    if (editing && onDelete != null) {
                        Box(
                            Modifier
                                .align(Alignment.TopStart)
                                .padding(start = 0.dp)
                                .size(26.dp)
                                .shadow(3.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Danger)
                                .clickable { onDelete(n) },
                            contentAlignment = Alignment.Center,
                        ) { Text("−", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            if (onAdd != null && !editing) {
                item(key = "add") {
                    Box(Modifier.padding(6.dp)) {
                        Box(
                            Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(color.copy(alpha = 0.05f))
                                .drawBehind {
                                    drawRoundRect(
                                        color = color.copy(alpha = 0.6f),
                                        cornerRadius = CornerRadius(20.dp.toPx()),
                                        style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
                                    )
                                }
                                .clickable { onAdd() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("+", fontSize = 36.sp, color = color, fontWeight = FontWeight.Light)
                                Text("Ajouter", fontSize = 11.sp, color = color)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** A delete waiting for the user's OK (only asked when the folder is not empty). */
class PendingDelete(val name: String, val count: Int, val action: () -> Unit)

@Composable
fun DeleteFolderDialog(pending: PendingDelete?, onClose: () -> Unit) {
    val p = pending ?: return
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Supprimer « ${p.name} » ?") },
        text = {
            Text(
                "Ce dossier contient ${countLabel(p.count)} (leçons, révisions ou examens).\n\n" +
                    "Êtes-vous sûr de vouloir supprimer ce dossier et tout son contenu ? " +
                    "Les photos et PDF seront supprimés du téléphone."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                p.action()
                onClose()
            }) { Text("Supprimer", color = Danger, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Annuler") } },
    )
}

// ---------------------------------------------------------------- files

data class ThumbState(val loading: Boolean, val missing: Boolean, val bitmap: ImageBitmap?)

@Composable
fun rememberThumb(ref: FileRef): ThumbState {
    val ctx = LocalContext.current.applicationContext
    val state by produceState(ThumbState(true, false, null), ref.uri) {
        value = withContext(Dispatchers.IO) {
            if (!FileAccess.exists(ctx, ref.uri)) ThumbState(false, true, null)
            else ThumbState(false, false, FileAccess.thumbnail(ctx, ref, 220)?.asImageBitmap())
        }
    }
    return state
}

@Composable
fun FileRow(ref: FileRef, onClick: (() -> Unit)?, onRemove: (() -> Unit)?) {
    val thumb = rememberThumb(ref)
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(2.dp, shape)
            .clip(shape)
            .background(Color.White)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFEDF2F1)),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = thumb.bitmap
            if (bmp != null) {
                Image(bmp, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Text(if (ref.isPdf) "📄" else "🖼️", fontSize = 26.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ref.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                when {
                    thumb.missing -> "⚠️ Introuvable sur le téléphone (supprimé ou déplacé ?)"
                    ref.isPdf -> "PDF"
                    else -> "Photo"
                },
                fontSize = 12.sp,
                color = if (thumb.missing) Danger else Muted,
            )
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = Muted)
            }
        }
    }
}
