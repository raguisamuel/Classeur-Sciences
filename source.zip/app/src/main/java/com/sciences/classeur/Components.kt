package com.sciences.classeur

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Teal = Color(0xFF14524F)
val Bg = Color(0xFFF4F7F7)
val Line = Color(0xFFDDE3E3)
val Muted = Color(0xFF66727A)
val Danger = Color(0xFFC62828)

@Composable
fun ClasseurTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Teal, background = Bg, surface = Color.White),
        content = content,
    )
}

@Composable
fun Header(
    title: String,
    subtitle: String?,
    color: Color,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(color)
            .padding(horizontal = 6.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour", tint = Color.White)
            }
        } else {
            Spacer(Modifier.width(14.dp))
        }
        Column(
            Modifier
                .weight(1f)
                .padding(vertical = 4.dp)
        ) {
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (!subtitle.isNullOrEmpty()) {
                Text(subtitle, color = Color.White.copy(alpha = 0.88f), fontSize = 13.sp)
            }
        }
        actions()
    }
}

/** Big coloured tile used on the home and section screens. */
@Composable
fun BigButton(title: String, subtitle: String?, emoji: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(color)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 32.sp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Color.White)
    }
}

/** White list row: folders and saved items. */
@Composable
fun FolderRow(emoji: String, title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 26.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = Muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Muted)
    }
}

@Composable
fun Question(text: String) {
    Text(text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
fun ChoiceList(question: String, options: List<String>, color: Color, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Question(question)
        options.forEachIndexed { i, option ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(2.dp, color.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    .clickable { onPick(i) }
                    .padding(horizontal = 18.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(option, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = color, modifier = Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = color)
            }
        }
    }
}

@Composable
fun NumberGrid(question: String, numbers: IntRange, caption: String, color: Color, onPick: (Int) -> Unit) {
    Column {
        Question(question)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(numbers.toList()) { n ->
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(color.copy(alpha = 0.10f))
                        .border(1.5.dp, color.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .clickable { onPick(n) },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(caption, fontSize = 10.sp, color = color)
                        Text("$n", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = color)
                    }
                }
            }
        }
    }
}

data class ThumbState(val loading: Boolean, val missing: Boolean, val bitmap: ImageBitmap?)

@Composable
fun rememberThumb(ref: FileRef): ThumbState {
    val ctx = LocalContext.current.applicationContext
    val state by produceState(ThumbState(true, false, null), ref.uri) {
        value = withContext(Dispatchers.IO) {
            if (!FileAccess.exists(ctx, ref.uri)) ThumbState(false, true, null)
            else ThumbState(false, false, FileAccess.thumbnail(ctx, ref, 220)?.asImageBitmap())
        }
    }
    return state
}

@Composable
fun FileRow(ref: FileRef, onClick: (() -> Unit)?, onRemove: (() -> Unit)?) {
    val thumb = rememberThumb(ref)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, Line, RoundedCornerShape(12.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFEDEFF1)),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = thumb.bitmap
            if (bmp != null) {
                Image(bmp, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Text(if (ref.isPdf) "📄" else "🖼️", fontSize = 26.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ref.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                when {
                    thumb.missing -> "⚠️ Introuvable sur le téléphone (supprimé ou déplacé ?)"
                    ref.isPdf -> "PDF"
                    else -> "Photo"
                },
                fontSize = 12.sp,
                color = if (thumb.missing) Danger else Muted,
            )
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Delete, contentDescription = "Retirer", tint = Muted)
            }
        }
    }
}
