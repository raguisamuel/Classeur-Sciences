package com.sciences.classeur

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import android.widget.Toast
import androidx.exifinterface.media.ExifInterface

/**
 * The app keeps ONE copy of every paper, in its own organised folder on the phone:
 *   Documents / Classeur Sciences / Leçons / 4ème année / 1er semestre / Chapitre 2 / Leçon 3 / …
 * The phone's file manager and gallery see these files too. After copying, the original
 * can be deleted so the paper is not stored twice.
 */
object FileAccess {
    const val ROOT = "Documents/Classeur Sciences"

    private val thumbs = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    private fun prefs(context: Context) = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun deleteOriginals(context: Context) = prefs(context).getBoolean("deleteOriginals", true)
    fun setDeleteOriginals(context: Context, value: Boolean) = prefs(context).edit().putBoolean("deleteOriginals", value).apply()

    /** Name and type of a file just chosen in the picker (not copied yet). */
    fun describe(context: Context, uri: Uri): FileRef {
        val cr = context.contentResolver
        var name: String? = null
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (_: Exception) {
        }
        val n = name ?: uri.lastPathSegment ?: "fichier"
        val mime = cr.getType(uri) ?: if (n.endsWith(".pdf", true)) "application/pdf" else "image/jpeg"
        return FileRef(uri.toString(), n, mime)
    }

    data class ImportResult(val copied: List<FileRef>, val failed: Int, val originalsKept: Int)

    /** Copies the chosen files into the app folder (call on a background thread). */
    fun importAll(context: Context, sources: List<FileRef>, folder: String, deleteOriginals: Boolean): ImportResult {
        val copied = mutableListOf<FileRef>()
        var failed = 0
        var kept = 0
        for (src in sources) {
            val copy = importFile(context, src, folder)
            if (copy == null) {
                failed++
                continue
            }
            copied.add(copy)
            if (deleteOriginals && !deleteOriginal(context, Uri.parse(src.uri))) kept++
        }
        return ImportResult(copied, failed, kept)
    }

    private fun importFile(context: Context, src: FileRef, folder: String): FileRef? {
        val cr = context.contentResolver
        val mime = when {
            src.isPdf -> "application/pdf"
            src.mime.startsWith("image/") && src.mime != "image/*" -> src.mime
            else -> "image/jpeg"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, src.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val dest = try {
            cr.insert(MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
        } catch (_: Exception) {
            null
        } ?: return null
        return try {
            cr.openInputStream(Uri.parse(src.uri))!!.use { input ->
                cr.openOutputStream(dest)!!.use { output -> input.copyTo(output) }
            }
            cr.update(dest, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            var finalName = src.name // Android may rename to "photo (1).jpg" if the name exists
            cr.query(dest, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) finalName = c.getString(0) ?: src.name
            }
            FileRef(dest.toString(), finalName, mime)
        } catch (_: Exception) {
            runCatching { cr.delete(dest, null, null) }
            null
        }
    }

    private fun deleteOriginal(context: Context, uri: Uri): Boolean = try {
        if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.deleteDocument(context.contentResolver, uri)
        else context.contentResolver.delete(uri, null, null) > 0
    } catch (_: Exception) {
        false
    }

    /** Deletes the app's copy (the only copy) of a file. */
    fun deleteCopy(context: Context, uri: String) {
        thumbs.remove(uri)
        runCatching { context.contentResolver.delete(Uri.parse(uri), null, null) }
    }

    fun exists(context: Context, uri: String): Boolean = try {
        context.contentResolver.openFileDescriptor(Uri.parse(uri), "r")?.use { true } ?: false
    } catch (_: Exception) {
        false
    }

    /** Opens the file in another app of the phone (PDF reader, gallery...). */
    fun openExternally(context: Context, ref: FileRef) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(ref.uri), ref.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "Aucune application pour ouvrir ce fichier.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(context, "Fichier introuvable.", Toast.LENGTH_LONG).show()
        }
    }

    /** Opens Android's share sheet (WhatsApp, Messenger, Gmail...) for one or several files. */
    fun share(context: Context, refs: List<FileRef>) {
        if (refs.isEmpty()) return
        val uris = refs.map { Uri.parse(it.uri) }
        val type = when {
            refs.all { it.isPdf } -> "application/pdf"
            refs.none { it.isPdf } -> if (refs.size == 1) refs[0].mime else "image/*"
            else -> "*/*"
        }
        val send = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        send.type = type
        send.clipData = ClipData.newRawUri(null, uris[0]).also { clip -> uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) } }
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(Intent.createChooser(send, "Partager via"))
        } catch (_: Exception) {
            Toast.makeText(context, "Impossible de partager ce fichier.", Toast.LENGTH_LONG).show()
        }
    }

    fun thumbnail(context: Context, ref: FileRef, size: Int): Bitmap? {
        thumbs.get(ref.uri)?.let { return it }
        val bmp = try {
            if (ref.isPdf) pdfFirstPage(context, ref, size) else loadImage(context, ref, size)
        } catch (_: Throwable) {
            null
        }
        if (bmp != null) thumbs.put(ref.uri, bmp)
        return bmp
    }

    /** Decodes an image scaled down so its longest side is about [maxSide] px, upright. */
    fun loadImage(context: Context, ref: FileRef, maxSide: Int): Bitmap? = try {
        val cr = context.contentResolver
        val uri = Uri.parse(ref.uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / (sample * 2) >= maxSide) sample *= 2
        val bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        val degrees = try {
            cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        } catch (_: Exception) {
            0
        }
        if (bmp != null && degrees != 0) {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees.toFloat()) }, true)
        } else bmp
    } catch (_: Throwable) {
        null
    }

    private fun pdfFirstPage(context: Context, ref: FileRef, width: Int): Bitmap? =
        context.contentResolver.openFileDescriptor(Uri.parse(ref.uri), "r")?.use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                if (renderer.pageCount == 0) return@use null
                renderer.openPage(0).use { page ->
                    val h = (width * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            }
        }
}
